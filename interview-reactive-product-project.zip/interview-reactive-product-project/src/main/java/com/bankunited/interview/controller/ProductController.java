package com.bankunited.interview.controller;

import com.bankunited.interview.domain.Product;
import com.bankunited.interview.service.ProductService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/products")
@AllArgsConstructor
public class ProductController {

    private final ProductService productService;

    @GetMapping
    private Flux<Product> getProducts() {
        return Flux.fromStream(productService.getProductStream());
    }
}
