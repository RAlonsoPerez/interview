package com.bankunited.interview.service;

import com.bankunited.interview.domain.Product;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

@Service
@AllArgsConstructor
public class ProductService {

    private final ObjectMapper objectMapper;

    public Stream<Product> getProductStream() {
        List<Product> productList = fromJsonArray(readStringFromFile("/", "products.json"), Product[].class);
        return productList.stream();
    }


    public String readStringFromFile(String directory, String file) {
        try {
            var bytes = (new ClassPathResource(directory + file)).getInputStream().readAllBytes();
            return new String(bytes);
        } catch (Exception e) {
            throw new RuntimeException("Error reading file " + file, e);
        }
    }

    public <T> List<T> fromJsonArray(String json, Class<T[]> type) {
        try {
            if (!StringUtils.isBlank(json) && json.length() > 2) {
                T[] jsonArray = objectMapper.readValue(json, type);
                return Arrays.asList(jsonArray);
            } else {
                return Collections.emptyList();
            }
        } catch (Exception e) {
            throw new RuntimeException("Error creating list with type: " + type + " from json array string: " + json, e);
        }
    }
}
