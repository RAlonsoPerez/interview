package com.bankunited.interview.domain;

import lombok.Data;

@Data
public class Product {
    private Integer externalProductId;
    private String productTypeName;
    private String externalProductKindId;
}
